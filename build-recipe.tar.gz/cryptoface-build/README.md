# CryptoFace GPU native build inputs

This archive supplies the checksum-verified sources used by the automatic
submission bootstrap. Run the benchmark from the main repository using
its submission instructions.
